// Example_sorting.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
using namespace std;

template <typename T>
void bubbleSort(T arr[], int length, int direction)
{
	int i, j;
	for (i = 1; i < length; i++)
		for (j = 0; j < length - i ; j++)
			if (arr[j] < arr[j + 1])
				swap(arr[j], arr[j + 1]);
}
template <typename T>
void printArray(T arr[], int size)
{
	int i;
	for (i = 0; i < size; i++)
		cout << arr[i] << " ";
	cout << endl;
}

// Driver code 
int main()
{
	int arr[] = { 5, 1, 4, 2, 8 };
	
	bubbleSort(arr, 5,0);
	cout << "Sorted array: \n";
	printArray(arr, 5);
	return 0;
}


